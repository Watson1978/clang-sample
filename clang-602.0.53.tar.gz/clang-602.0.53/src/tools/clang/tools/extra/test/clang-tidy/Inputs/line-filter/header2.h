class A2 { A2(int); };
class B2 { B2(int); };
class C2 { C2(int); };
