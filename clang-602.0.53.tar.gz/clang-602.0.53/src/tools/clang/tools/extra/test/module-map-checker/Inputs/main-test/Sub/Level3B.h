#define MACRO_3B 1
