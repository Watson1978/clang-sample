class A2 { A2(int); };
