namespace {
int x;
}

namespace spaaaace {
class core;
}
