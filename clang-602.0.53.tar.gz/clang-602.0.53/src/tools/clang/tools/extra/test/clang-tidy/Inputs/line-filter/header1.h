class A1 { A1(int); };
class B1 { B1(int); };
class C1 { C1(int); };
