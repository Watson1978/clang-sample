class A3 { A3(int); };
