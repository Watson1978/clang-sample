void foo() {
  int *p = nullptr;
  int *k = nullptr;
}
