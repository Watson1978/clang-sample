class A1 { A1(int); };
